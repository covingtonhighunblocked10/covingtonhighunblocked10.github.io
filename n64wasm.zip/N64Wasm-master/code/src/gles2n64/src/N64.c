#include <stdint.h>
#include "N64.h"

extern uint8_t *DMEM;
uint64_t TMEM[512];
uint8_t *RDRAM;
uint32_t RDRAMSize;
