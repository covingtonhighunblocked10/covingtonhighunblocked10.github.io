#ifndef F3DPD_H
#define F3DPD_H

#ifdef __cplusplus
extern "C" {
#endif

#define F3DPD_VTXCOLORBASE      0x07

void F3DPD_Init(void);

#ifdef __cplusplus
}
#endif

#endif

