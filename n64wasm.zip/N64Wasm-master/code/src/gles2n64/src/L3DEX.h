#ifndef L3DEX_H
#define L3DEX_H

#ifdef __cplusplus
extern "C" {
#endif

#include <stdint.h>

void L3DEX_Line3D( uint32_t w0, uint32_t w1 );
void L3DEX_Init(void);

#ifdef __cplusplus
}
#endif

#endif

