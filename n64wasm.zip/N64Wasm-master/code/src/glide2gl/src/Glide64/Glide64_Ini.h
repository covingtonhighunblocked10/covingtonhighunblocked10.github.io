#ifndef _GLIDE64_INI_OVER_H
#define _GLIDE64_INI_OVER_H

void ReadSpecialSettings (const char * name);
void ReadSettings(void);

#endif
