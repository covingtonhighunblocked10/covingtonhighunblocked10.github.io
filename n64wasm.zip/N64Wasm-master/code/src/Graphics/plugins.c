#include <stdint.h>

#include "plugin.h"

/* Just setting this to something, and GFX_GLIDE64 is 0 */
enum gfx_plugin_type gfx_plugin = GFX_GLIDE64;
