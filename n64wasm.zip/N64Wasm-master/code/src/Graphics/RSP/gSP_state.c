#include "gSP_state.h"

struct gSPInfo gSP;
