#ifndef RSP_CPU_STATE_HPP
#define RSP_CPU_STATE_HPP


#endif